# Analyzing-Historical-Stock-Revenue-Data-and-Building-a-Dashboard
Peer-graded Assignment: As a data scientist working for an investment firm, you will extract the revenue data for Tesla and GameStop and build a dashboard to compare the price of the stock vs the revenue. 
